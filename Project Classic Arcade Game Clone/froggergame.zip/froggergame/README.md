frontend-nanodegree-arcade-game
===============================
Objective of this game is to reach the water at the top of game board

Player can move left, right, up, down by using the keyboard arrow keys

If player collides with any of the enemies,the game will over and will reset to starting position

The enemies can start in random rows and at random speeds everytime when game is reset.
